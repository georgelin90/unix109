#define _GNU_SOURCE
#include <regex.h>
#include <errno.h>
#include <inttypes.h>
#include <sys/types.h>
#include <pwd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
int inodenum[1000], lastpid = 0, errnum;
char *c = NULL, *f = NULL, *t = NULL, *R = "REG", *C = "CHR", *D= "DIR", *F = "FIFO", *S = "SOCK", *U = "unknown";
const char s[2] = " ";
int checkregex(char *reg)
{
	if(f == NULL)
		return 1;
	int regflag = 0;
	char *curr;
        if(strlen(f) > strlen(reg))
                return 0;
        else{
              for(int i = 0; i <= strlen(reg) - strlen(f); i++)
                {
			curr = reg + i;
                        if(strncmp(curr, f, strlen(f)) == 0)
                        {
                                regflag = 1;
                                return 1;
                        }
                }
                return 0;
             }
}
void readcontent(char *name)
{
/*	regex_t regex;
	int ret;
	ret = regcomp(&regex, c, 0);
	if(ret !=0)
	{
		perror("regcomp");
		exit(EXIT_FAILURE);
	}*/
	FILE* fp;
	char path[20] = "/proc/";
	strncat(path, name, 4);
	//read comm
	char commpath[20] = "\0";
	for(int i = 0; i < strlen(path); i++)
	{
		commpath[i] = path[i];
	}
	char temp[20] = "/comm";
	strncat(commpath, temp, 6);
	fp = fopen(commpath, "r");
	char comm[100];
	if(fp == NULL)
	{
		perror("fopen");
		exit(EXIT_FAILURE);
	}
	if(fp != NULL)
	{
		fgets(comm,100, fp);
		comm[strcspn(comm, "\n")] = 0;
	}
	fclose(fp);
	int cflag = 0;
	char *cur;
	if(c != NULL)
	{
		if(strlen(c) > strlen(comm))
			return;
		else{
		for(int i = 0; i <= strlen(comm) - strlen(c); i++)
		{
			cur = &comm[0] +i;
			if(strncmp(cur, c, strlen(c)) == 0)
			{
				cflag = 1;
				break;
			}
		}
		if(cflag == 0) return;
		}
	}
	//read uid
	ssize_t bufsiz = PATH_MAX;
	char uidpath[20] = "\0", uidtemp[20] = "/loginuid", *uidbuf;
	uidbuf = malloc(bufsiz);
	for(int i = 0; i < strlen(path); i++)
	{
		uidpath[i] = path[i];
	}
	strncat(uidpath, uidtemp, 9);
	fp = fopen(uidpath, "r");
	char userid[100];
	if(fp != NULL)
	{
		fgets(userid, 100, fp);
	}
        fclose(fp);
	unsigned int nid = atoi(userid);
	if(nid == 4294967295)
		nid = 0;
	struct passwd *pws;
	pws = getpwuid(nid);
	//read cwd
	char cwdpath[20] = "\0", temp2[20] = "/cwd", *buf;
	buf = malloc(bufsiz);
	for(int i = 0; i < strlen(path); i++)
	{
		cwdpath[i] = path[i];
	}
	strncat(cwdpath, temp2, 4);
	ssize_t v; 
	if((v = readlink(cwdpath, buf, bufsiz)) != -1)
	{
		buf[v] = '\0';
		struct stat st;
	        stat(cwdpath, &st);
		if(checkregex(buf)){
		if(t != NULL){
			if(strcmp(t, D)== 0)
       				printf("%s\t%s\t%s\tcwd\tDIR\t%lu\t%s\n", comm, name, pws->pw_name, st.st_ino, buf);
		}
		else
       			printf("%s\t%s\t%s\tcwd\tDIR\t%lu\t%s\n", comm, name, pws->pw_name, st.st_ino, buf);
		}
	}
	else
	{
		errnum = errno;
		if(checkregex(&cwdpath[0])){
		if( t != NULL){
			if(strcmp(t, U) == 0)
				printf("%s\t%s\t%s\tcwd\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, cwdpath, strerror(errnum));
		}
		else
			printf("%s\t%s\t%s\tcwd\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, cwdpath, strerror(errnum));
		}
	}
	//read root	
	char rootpath[20] = "\0", temp3[20] = "/root", *buf2;
	buf2 = malloc(bufsiz);
	for(int i = 0; i < strlen(path); i++)
	{
		rootpath[i] = path[i];
	}
	strncat(rootpath, temp3, 5);
	ssize_t v2; 
	if((v2 = readlink(rootpath, buf2, bufsiz)) != -1)
	{
		buf2[v2] = '\0';
		struct stat st2;
		stat(rootpath, &st2);
		//print root
		if(checkregex(buf2)){
		if( t!= NULL){
			if(strcmp(t, D) ==0)
				printf("%s\t%s\t%s\troot\tDIR\t%lu\t%s\n", comm, name, pws->pw_name, st2.st_ino, buf2);
		}
		else
			printf("%s\t%s\t%s\troot\tDIR\t%lu\t%s\n", comm, name, pws->pw_name, st2.st_ino, buf2);
		}
	}
	else
	{
		errnum = errno;
		if(checkregex(&rootpath[0])){
		if(t != NULL){
			if(strcmp(t, U) == 0)
				printf("%s\t%s\t%s\troot\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, rootpath, strerror(errnum));
		}
		else
			printf("%s\t%s\t%s\troot\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, rootpath, strerror(errnum));
		}

	}
	//read exe	
	char exepath[20] = "\0", temp4[20] = "/exe", *buf3;
	buf3 = malloc(bufsiz);
	for(int i = 0; i < strlen(path); i++)
	{
		exepath[i] = path[i];
	}
	strncat(exepath, temp4, 4);
	ssize_t v3; 
	if((v3= readlink(exepath, buf3, bufsiz)) !=-1)
	{
		buf3[v3] = '\0';
		struct stat st3;
		stat(exepath, &st3);
		//print exe
		if(checkregex(buf3)){
		if( t != NULL){
			if(strcmp(t, R) == 0)
				printf("%s\t%s\t%s\texe\tREG\t%ju\t%s\n", comm, name, pws->pw_name, (uintmax_t)st3.st_ino, buf3);
		}
		else
			printf("%s\t%s\t%s\texe\tREG\t%ju\t%s\n", comm, name, pws->pw_name, (uintmax_t)st3.st_ino, buf3);
			}
	}
	else
	{
		errnum = errno;
		if(checkregex(&exepath[0])){
		if(t != NULL){
			if(strcmp(t, U) == 0)
				printf("%s\t%s\t%s\texe\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, exepath, strerror(errnum));
		}
		else
			printf("%s\t%s\t%s\texe\tunknown\t%s (readlink: %s)\n", comm, name, pws->pw_name, exepath, strerror(errnum));
			}
	}
	//read maps
	char mapspath[20] = "\0", temp5[20] = "/maps";	
	for(int i = 0; i < strlen(path); i++)
	{
		mapspath[i] = path[i];
	}
	char data[200];
	strncat(mapspath, temp5, 5);
	fp = fopen(mapspath, "r");
	if(fp != NULL){
	fseek(fp, 0, SEEK_END);
	long fsize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	int index = 0;
	int in, flag = 1, delflag = 0;
	char *token, *token2, *token3, *pos;
	for(int i =0; i < 1000; i++)
		inodenum[i] = 0;
	while(1){
	delflag = 0;
	fseek(fp, 46, SEEK_CUR);
	fgets(data, 200, fp);
	token = strtok(data, s);
	token2 = strtok(NULL, s);
	token3 = strtok(NULL, s);
	if(token3 != NULL)
	{
		delflag = 1;
	}
	in = atoi(token);
	flag = 1;
	for(int i = 0; i < 1000; i++)
	{
		if(in == inodenum[i])
		{
			flag = 0;
			break;
		}
	}
	if(flag == 1)//print maps
	{
		if(checkregex(token2)){
		if(delflag == 1)
		{
			if(t != NULL){
			      if (strcmp(t, U) == 0){
					inodenum[index] = in;
					index++;
					printf("%s\t%s\t%s\tdel\tunknown\t%s\t%s %s",comm, name, pws->pw_name,  token, token2, token3);
			}
			}
			else
			{
				inodenum[index] = in;
				index++;
				printf("%s\t%s\t%s\tdel\tunknown\t%s\t%s %s",comm, name, pws->pw_name,  token, token2, token3);
			}
		}
		else{
		if(t != NULL){
			if(strcmp(t, R) == 0){
				inodenum[index] = in;
				index++;
				printf("%s\t%s\t%s\tmem\tREG\t%s\t%s",comm, name, pws->pw_name,  token, token2);
			}
		}
		else{
			inodenum[index] = in;
			index++;
			printf("%s\t%s\t%s\tmem\tREG\t%s\t%s",comm, name, pws->pw_name,  token, token2);
		}
		}
		}
	}
	else
	{
		;
	}
	if(feof(fp))
		break;
	}
	fclose(fp);
	}
	else ;
	//read fd
	char fdpath[20] = "\0", temp6[20] = "/fd";
	for(int i = 0; i < strlen(path); i++)
	{
		fdpath[i] = path[i];
	}
	strncat(fdpath, temp6, 3);
	DIR *dir;
	struct dirent *dent;
	dir = opendir(fdpath);
	char *buf4,fdlink[20], *fdtoken, *fdtoken2, *tmp;
	buf4 = malloc(bufsiz);
	int dfd, fdflag;
	ssize_t v4;
	struct stat st4;
	char *fd_type, *fd_mode;
	if(dir != NULL)
	{
		int cnt =0;
		while((dent = readdir(dir)) !=NULL)
		{
			if(cnt < 2)
			{
				cnt++;
				continue;
			}
			fdflag = 0;
			dfd = dirfd(dir);
			for(int i = 0; i<20; i++)
				fdlink[i] = '\0';
			for(int i = 0; i < strlen(fdpath); i++)
				fdlink[i] = fdpath[i];
			fdlink[strlen(fdlink)] = '/';
			strcat(fdlink, dent->d_name);
			stat(fdlink, &st4);
			if((v4 = readlink(fdlink, buf4, bufsiz)) != -1)
				buf4[v4] = '\0';
			else
			{
				errnum = errno;
				printf("%s\t%s\t%s\tNOFD\t\t%s (readlink: %s)\n", comm, name, pws->pw_name, fdpath, strerror(errnum));
				break;
			}
			strcpy(temp, buf4);
			fdtoken = strtok(temp, s);
			fdtoken2 = strtok(NULL, s);
			if(fdtoken2 != NULL)
			{
			//	printf("del: %s\t%s\n", fdtoken2, buf4);
				fdflag = 1;
			}
	//		printf("%s\n", buf4);
			switch (st4.st_mode & S_IFMT) {
			   case S_IFCHR:  fd_type = "CHR";        break;
		           case S_IFDIR:  fd_type = "DIR";        break;
		           case S_IFIFO:  fd_type = "FIFO";       break;
		           case S_IFREG:  fd_type = "REG";        break;
		           case S_IFSOCK: fd_type = "SOCK";       break;
		           default:       fd_type = "unknown";    break;
          		 }

			/*if ((st4.st_mode & 0700) == S_IRWXU)
				fd_mode = "u";
			else if ((st4.st_mode & 0700)  == S_IRUSR)
				fd_mode = "r";
			else if ((st4.st_mode & 0700)  == S_IWUSR)
				fd_mode = "w";
			else
				fd_mode = ":(";*/
			switch (st4.st_mode & 0700){
				case 0700:    fd_mode = "u";	break;
				case 0600:    fd_mode = "u";	break;
				case 0500:    fd_mode = "r";	break;
				case 0400:    fd_mode = "r";	break;
				case 0300:    fd_mode = "w";	break;
				case 0200:    fd_mode = "w";	break;
				case 0100:    fd_mode = "x";	break;
				default:      fd_mode = ":(";	break;
			}
//			printf("mode:%u\n", st4.st_mode & 0700);
			//print fd
			if(checkregex(buf4)){
			if(fdflag == 1)
			{
				if(t != NULL){
					if(strcmp(t, U) == 0)
						printf("%s\t%s\t%s\t%s%s\tunknown\t%lu\t%s\n", comm, name, pws->pw_name, dent->d_name, fd_mode, st4.st_ino, buf4);
				}
				else
					printf("%s\t%s\t%s\t%s%s\tunknown\t%lu\t%s\n", comm, name, pws->pw_name, dent->d_name, fd_mode, st4.st_ino, buf4);
			}
			else{
			if(t != NULL){
			       	if(strcmp(t, fd_type) == 0)
					printf("%s\t%s\t%s\t%s%s\t%s\t%lu\t%s\n", comm, name, pws->pw_name, dent->d_name, fd_mode, fd_type, st4.st_ino, buf4);
			}
			else 
				printf("%s\t%s\t%s\t%s%s\t%s\t%lu\t%s\n", comm, name, pws->pw_name, dent->d_name, fd_mode, fd_type, st4.st_ino, buf4);
			}
			}
		}
	}
	else
	{
		errnum = errno;
		if(checkregex(&fdpath[0])){
		if(t == NULL)
		printf("%s\t%s\t%s\tNOFD\t\t%s (opendir: %s)\n", comm, name, pws->pw_name, fdpath, strerror(errnum));
		}
	}
}
int main(int argc, char *argv[]) {
	int ch;
	while((ch = getopt(argc, argv, "c:t:f:")) != -1) {
		switch(ch) {
		case 'c':
			c = optarg;
			break;
		case 't':
			t = optarg;
			if((strcmp(t, R) && strcmp(t, C) && strcmp(t, D) && strcmp(t, F) && strcmp(t, S) && strcmp(t, U)) != 0)
			{
				printf("Invalid TYPE option.\n");
				return 0;
			}
			break;
		case 'f':
			f = optarg;
			break;
		case '?':
		case ':':
		default:
			printf("bad option: %c\n", ch);
			break;
		}
	}
	char *dirp = "/proc";
	struct dirent **namelist;
	int n;
	n = scandir( dirp, &namelist, NULL, versionsort);	
	if( n == -1) 
	{
		perror("scandir");
		exit( EXIT_FAILURE);
	}
	int i = 2;
	printf("COMMAND\tPID\tUSER\tFD\tTYPE\tNODE\tNAME\n");
	while(namelist[i]->d_name[0]-'0'<10)
	{
		readcontent(namelist[i]->d_name);
		i++;
	}
	lastpid = i;
	for(int i = 0; i < n; i++)
	{
		free(namelist[n]);
	}
	exit(EXIT_SUCCESS);
	return 0;
}

